const config = require('config.json');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('helpers/db');
const Account = db.Account;

module.exports = {   
    getAll,
    getById,
    getByUserId,
    create,
    update,
    delete: _delete
};

async function getAll() {
    return await Account.find();
}

async function getById(id) {
    return await Account.find(id);
}

async function getByUserId(userId) {
    return await Account.find(x => x.userId == userId);
}

async function create(accountParam) {    

    if(accountParam?.userId == "" ) throw 'An error occurred'    

    const account = new Account(accountParam);      
    await account.save();
}

async function update(id, accountParam) {
    const account = await Account.findById(id);

    // validate
    if (!account) throw 'Account not found';     
    
    if(accountParam.action === "Deposit")
        makeDeposit(account, accountParam.amount)
    else if(accountParam.action === "Withdrawal")
        makeWithdrawal(account, accountParam.amount)    
    else {
        // copy accountParam properties to account
        Object.assign(account, accountParam);
    }   

    await account.save();
}

async function _delete(id) {
    await Account.findByIdAndRemove(id);
}

function makeDeposit(account, amount) {
    account.balance = parseFloat((account.balance + amount).toFixed(2));
    return account;
}

function makeWithdrawal(account, amount) {
    account.balance = parseFloat((account.balance - amount).toFixed(2));
    return account;
}