Run Web API
---------------------------------------------------------------------
1. Install NodeJS and NPM from  https://nodejs.org/en/download/.
2. Install MongoDB Community Server from  https://www.mongodb.com/download-center.
3. Run MongoDB
4. Install all required npm packages by running "npm install" from the command line in the project root folder.
5. Start the api by running "npm start" from the command line in the project root folder


Run Mobile APP
---------------------------------------------------------------------
1. Install all required npm packages by running "npm install" from the command line in the project root folder.
2. Start the APP by running "ionic serve" from the command line in the project root folder





POST:

http://localhost:4000/users/register

{
    "firstName": "Walter",
    "lastName": "Molobela",
    "username": "walter",
    "password": "password1",
	 "age": 34
}


POST:
http://localhost:4000/users/authenticate

{
    "username": "walter",
    "password": "password1"
}


GET:
http://localhost:4000/users
http://localhost:4000/users/1