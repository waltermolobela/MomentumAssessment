import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { map, tap } from 'rxjs/operators';
import { AuthenticationService } from '../services/authentication.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  isSubmitted = false;
  errorMsg: string;

  registerForm = this.formBuilder.group({
    firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    username: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(20)]],
    password: ['', [Validators.required,
    Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!#%*?&])[A-Za-z\d$@$#!%*?&].{6,}')]],
    confirmPassword: ['', [Validators.required]],
    mobile: ['', [Validators.pattern('[0-9 ]{10}')]],
    age: ['', [Validators.required, Validators.pattern('[0-9]{1,2}')]],
    emailAddress: ['', [Validators.required, Validators.email]],
  },
    { validator: this.checkPasswords });

  constructor(private userService: UserService, private nav: NavController, private authService: AuthenticationService,
    private formBuilder: FormBuilder) { }

  ngOnInit() { }

  ionViewWillEnter() {
    this.errorMsg = null;
    this.isSubmitted = false;
  }

  ionViewDidLeave() {
    console.warn('ionViewWillLeave: login page');
    this.registerForm.reset();
  }

  register() {

    this.isSubmitted = true;
    if (this.registerForm.invalid) { return; }

    this.userService.register(this.registerForm.value).pipe(
      tap({
        next: response => (response),
        error: (error) => {
          this.errorMsg = 'An error has occurred.';
          console.error('Error: ', JSON.stringify(error));
          return;
        }
      }),
      map(response => {
        console.warn(JSON.stringify(response));
        this.nav.navigateRoot(['/login']);
      }),
    ).subscribe();
  }

  checkPasswords(group: FormGroup) { // here we have the 'passwords' group
    const pass = group.get('password').value;
    const confirmPass = group.get('confirmPassword').value;

    if (pass !== confirmPass) {
      group.controls.confirmPassword.setErrors({ nomatch: true });
    }

    return pass === confirmPass ? null : { notSamePassword: true };
  }
}
