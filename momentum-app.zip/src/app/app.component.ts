import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { AuthenticationService } from './services/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  isLoggedIn = false;
  constructor( private platform: Platform,
    private authenticationService: AuthenticationService,
    private router: Router
  ) {
    this.initializeApp();
  }

  initializeApp() {
     this.platform.ready().then(() => {
       this.authenticationService.authenticationState.subscribe(state => {
         console.warn(state);

         if (!state) {
          this.router.navigate(['home']);
          this.isLoggedIn = false;
         }
         else {
            this.isLoggedIn = true;
         }
       });
    });
  }

  logout() {
    this.authenticationService.logout();
  }
}
