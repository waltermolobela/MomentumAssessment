import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { map, tap} from 'rxjs/operators';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  isSubmitted  =  false;
  errorMsg: string;
  loginResults: any;

  loginForm  =  this.formBuilder.group({
    username: ['', Validators.required],
    password: ['', Validators.required]
  });

  constructor(private auth: AuthenticationService, private nav: NavController,  private formBuilder: FormBuilder ) { }

  ngOnInit() { }

  get formControls() { return this.loginForm.controls; }

  ionViewWillEnter() {
    this.errorMsg = null;
    this.isSubmitted = false;

    this.auth.authenticationState.subscribe(state => {
      if (state) {
        this.nav.navigateRoot(['dashboard']);
      }
    });
  }

  ionViewDidLeave() {
    console.warn('ionViewWillLeave: login page');
    this.loginForm.reset();
    //this.loginResults.unsubscribe();
  }

  login() {
    this.isSubmitted = true;
    if (this.loginForm.invalid) { return; }

    this.loginResults = this.auth.login(this.loginForm.value).pipe(
      tap({
        next: response => (response),
        error: (error) => {
          if (error instanceof HttpErrorResponse) {
            if (error.status === 400) {
              this.errorMsg = 'The user name or password is incorrect.';
              return;
            }
          }
          this.errorMsg = 'An error has occurred. Please try again later';
          console.error('Error: ', JSON.stringify(error));
          return;
        }
      }),
      map(async response => {
        console.warn('Login response:', JSON.stringify(response));
        await this.auth.logout();
        await this.auth.setLoginToken(response.token);
        await localStorage.setItem('userId', response.id);
        await localStorage.setItem('userName', response.firstName);
        this.nav.navigateRoot(['/dashboard']);
      }),
    ).subscribe();
  }
}
