import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavController } from '@ionic/angular';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.page.html',
  styleUrls: ['./forgot-password.page.scss'],
})
export class ForgotPasswordPage implements OnInit {

  forgotPasswordForm: FormGroup;
  isSubmitted  =  false;
  errorMsg: string;

  constructor(private auth: AuthenticationService, private nav: NavController,  private formBuilder: FormBuilder ) { }

  ngOnInit() {
    this.forgotPasswordForm  =  this.formBuilder.group({
      emailAddress: ['', [Validators.required, Validators.email]],
    });
  }

  reset(){
    this.isSubmitted = true;

    if (this.forgotPasswordForm.invalid) {
      return;
    }
    this.errorMsg = 'Please try again later or contact admin!';
    return;
  }
}
