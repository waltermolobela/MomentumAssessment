import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})

export class TokenInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector) {}

  intercept(request, next) {

    const authService = this.injector.get(AuthenticationService);
    const token = authService.token;

    if (request.url.toString().includes('/token'))
       {return next.handle(request);}

    if (!token) {
      return next.handle(request);
    }

    request = request.clone({
      setHeaders: {
        'Authorization': `${token}`,
        'Content-Type': 'application/json',
      }
    });

    return next.handle(request);
  }
}

