import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { RegisterVM } from '../interfaces/registerVM';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl = `${environment.baseurl}/clients/`;
  constructor(private httpClient: HttpClient) { }

  register(user: RegisterVM): Observable<any> {
    return this.httpClient.post<RegisterVM>(this.baseUrl + 'register', user);
  }
  getUserDetails(id: string){
    return this.httpClient.get<RegisterVM>(this.baseUrl + id);
  }
}
