import { Platform } from '@ionic/angular';
import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
import { BehaviorSubject, Observable } from 'rxjs';
import { LoginVM } from '../interfaces/loginVM';
import { HttpClient } from '@angular/common/http';
import { AccessDetail } from '../interfaces/accessDetail';
import { environment } from 'src/environments/environment';

const TOKEN_KEY = 'auth-token';

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {

  baseUrl = `${environment.baseurl}/clients`;
  authenticationState = new BehaviorSubject(false);
  token: string;

  constructor(private httpClient: HttpClient, private storage: Storage, private plt: Platform) {
    this.plt.ready().then(() => {
      this.checkToken();
    });
  }

  async getToken(){
    return this.storage.get(TOKEN_KEY);
  }

  async checkToken() {
    await this.storage.create();
    this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        this.token = res;
        this.authenticationState.next(true);
      }
      else
      {
        this. logout();
      }
    });
  }

  async setLoginToken(token: string) {
    await this.logout();
    this.token = 'Bearer ' + token;
    return await this.storage.set(TOKEN_KEY, 'Bearer ' + token).then(() => {
      this.authenticationState.next(true);
    });
  }

  login(user: LoginVM): Observable<any> {
    const requestData = 'username=' + user.username + '&password=' + user.password;
    return this.httpClient.post<AccessDetail>(this.baseUrl + '/authenticate', user);

  }

  logout() {
    this.token = undefined;
    return this.storage.remove(TOKEN_KEY).then(() => {
      this.authenticationState.next(false);
    });
  }

  isAuthenticated() {
    return this.authenticationState.value;
  }
}
