import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { switchMap, map, startWith, distinctUntilChanged, filter, tap, first } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {

  username: string;
  userId: string = localStorage.getItem('userId');
  accounts = [];
  user = { name: null, };

  userDetail$ = this.userService.getUserDetails(this.userId).pipe(
    tap({
      next: response => (response),
      error: (error) => {
        console.warn('Error occurred, dashboard page, userDetails:', JSON.stringify(error));
        if (error instanceof HttpErrorResponse) {
          if (error.status === 401) {
            this.authService.logout();
          }
        }
      }
    }),
    map((response: any) => {
      console.warn(JSON.stringify(response));
      this.accounts = response.accounts;
      this.user.name = response.name;
      return response;
    })
  ).subscribe();

  constructor(private router: Router, private userService: UserService, private authService: AuthenticationService,) {}

  ngOnInit() {  }

  ionViewWillEnter() {
    console.warn('ionViewWillEnter: dashboard page');
    this.username = localStorage.getItem('userName');
    this.userId = localStorage.getItem('userId');
    this.getUserDetails();
  }

  ionViewWillLeave() {
    console.warn('ionViewWillLeave: dashboard page');
  }

  ionViewDidLeave() {
    console.warn('ionViewDidLeave: dashboard page');
  }

  getUserDetails() {
    this.userDetail$ = this.userService.getUserDetails(this.userId).pipe(
      tap({
        next: response => (response),
        error: (error) => {
          console.warn('Error occurred, dashboard page, userDetails:', JSON.stringify(error));
          if (error instanceof HttpErrorResponse) {
            if (error.status === 401) {
              this.authService.logout();
            }
          }
        }
      }),
      map((response: any) => {
        console.warn(JSON.stringify(response));
        this.accounts = response.accounts;
        this.user.name = response.name;
        return response;
      })
    ).subscribe();
  }
}
