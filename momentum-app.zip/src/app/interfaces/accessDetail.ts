export interface AccessDetail {
    access_token: string;
    username: string;
}
