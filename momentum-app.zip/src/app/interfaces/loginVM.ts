export interface LoginVM {
  username: string;
  password: string;
}
