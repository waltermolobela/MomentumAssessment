export interface RegisterVM {
  username: string | null;
    email: string | null;
    password: string | null;
    confirmPassword: string | null;
    firstName: string | null;
    lastName: string | null;
    age: number | null;
}
