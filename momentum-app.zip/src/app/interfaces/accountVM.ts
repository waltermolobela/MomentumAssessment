export interface AccountVM {
  balance: string;
  overdraft: string;
  userId: string;
}
